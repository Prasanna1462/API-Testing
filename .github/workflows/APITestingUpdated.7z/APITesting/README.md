# Test automation Project for API Testing
## Pre-requisites

JDK 1.7+ (make sure Java class path is set)
Maven (make sure .m2 class path is set)
TESTNG dependency
Maven



## Framework Structure


          APITesting
            |_src/main/java
		|_CommonValidation
		|	|_APIStatus.java
		|	|_CommonValidation.java
	                |_ValidationInterface
	                     |_DetailedErrorsInterface
             |_utility
                  |_ConfigReader.java
                  |_ExtentReportListner.java

           |_src/test/java
              |_DeleteOperation
              |_GetOperation
              |_PostOperation
              |_PutOperation
           |_src/test/resources
               |_Config.properties
               |_post.json
               |_put.json

	    |pom.xml
        |target
            |_ExtentReport
        |_README.md
        |testng.xml


src/test/resources/ - config file and json file

src/test/java/ - all java file

src/main/java/commonvalidation - Status code java file and common validation file

src/main/java/utility - configreader.java and ExtentReportLister.java file

target - Test Report will be generated here.


## Framework usage:

### API Testing

*Main purpose of this framework is for perform CRUD operation
*GET,PUT,DELETE,POST  methods created 
*Validated Status code and data from response

## Running the tests:

 we can use testng.xml file for running test directly, by right clicking on testng.xml file and run as testng.
Run test directly from Run menu option.



## Report Generation:

Report generated in target/ExtentReport folder







   









