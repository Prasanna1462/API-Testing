import CommonValidation.CommonValidation;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Reporter;
import org.testng.annotations.Test;
import utility.ConfigReader;
import CommonValidation.APIStatus;
import com.aventstack.extentreports.*;
import utility.ExtentReportListner;

import static io.restassured.RestAssured.given;

public class GetOperation extends ExtentReportListner {
public  static Response response;
    @Test (priority=1)
    void validGetRequest(){

        System.out.println("Test Case : Valid Get Request");
        //Get Operation
        String getHostGet = String.format("%s", "https://" + ConfigReader.getbaseURL());
        RequestSpecification request = given();
        response = request.get(getHostGet);
        int statusCode = response.getStatusCode();

        CommonValidation.verifyStatusCode(response,APIStatus.statusCodes.SUCCESS);

        System.out.println("Base URL: "+getHostGet);
        System.out.println("Get Status Code: "+statusCode);
        System.out.println("Response Body: "+response.asString());

        CommonValidation.verifyGetidValue(response,"1");
        System.out.println("Status Code : "+response.statusCode());

        testLog(getHostGet,response);
        expAndActual(String.valueOf(statusCode), String.valueOf(APIStatus.statusCodes.SUCCESS));

    }


    @Test (priority=2)
    void getRequestInvalid(){
        System.out.println("Test Case : Get Request Invalid Number");
        //Get Operation
        String getHostGet = String.format("%s", "https://" + ConfigReader.getbaseURL() + "111");
        RequestSpecification request = given();
        System.out.println("Base URL: "+getHostGet);
        response = request.get(getHostGet);
        int statusCode = response.getStatusCode();
        CommonValidation.verifyStatusCode(response,APIStatus.statusCodes.NOT_FOUND_404);
        System.out.println("Status Code : "+response.statusCode());
        Reporter.log("Response: "+response.asString());

        testLog(getHostGet,response);
        expAndActual(String.valueOf(statusCode), String.valueOf(APIStatus.statusCodes.NOT_FOUND_404));

    }



    @Test (priority=3)
    void invalidGetRequestSpecialchar(){
        System.out.println("Test Case : Invalid Get Request with Special Character ");
        String getHostGet = String.format("%s", "https://" + ConfigReader.getbaseURL()+"***");
        RequestSpecification request = given();
        System.out.println("Base URL: "+getHostGet);
        response = request.get(getHostGet);
        int statusCode=response.getStatusCode();
        CommonValidation.verifyStatusCode(response, APIStatus.statusCodes.NOT_FOUND_404);
        System.out.println("Invalid Get Request and Verify Response: "+response.asString());
        System.out.println("Status Code : "+response.statusCode());
        Reporter.log("Response: "+response.asString());

        testLog(getHostGet,response);
        expAndActual(String.valueOf(statusCode), String.valueOf(APIStatus.statusCodes.NOT_FOUND_404));
    }
}
