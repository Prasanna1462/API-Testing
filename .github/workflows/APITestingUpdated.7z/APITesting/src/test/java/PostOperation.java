import CommonValidation.CommonValidation;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;
import utility.ConfigReader;
import java.io.File;
import CommonValidation.APIStatus;
import utility.ExtentReportListner;

import static io.restassured.RestAssured.given;

public class PostOperation extends ExtentReportListner {
    public static Response response;

    @Test (priority=1)
    void postRequest() {
        System.out.println("Test Case : Post Request");
        //POST Operation
        File file = new File(ConfigReader.getpostjsonUrl());
        String postURL = String.format("%s", "https://" + ConfigReader.getbaseURL());

        RequestSpecification request = given();
        request.contentType("application/json").when().body(file);

        System.out.println("Base URL: "+postURL);
        System.out.println("Request Body: "+request.log().body());

        response = request.post(postURL);
        int statusCode = response.getStatusCode();
        CommonValidation.verifyStatusCode(response,APIStatus.statusCodes.SUCCESS_CREATED);

        System.out.println("Post Status Code: "+statusCode);
        System.out.println("Response Body: "+response.asString());

        String responesName = ConfigReader.getvalidName();

        //id is generating Dynamically, so compairing with the same id in common Validation,
        // Post will not effect the current API, it will display in response only.
        CommonValidation.verifyNameValue(response,responesName);
        System.out.println("Status Code : "+response.statusCode());
        testLog(postURL,response);
        expAndActual(responesName, response.jsonPath().get("name"));

    }

    @Test (priority=2)
    void inValidResponseData() {
        System.out.println("Test Case : Post Request invalid Response");
        //POST Operation
        File file = new File(ConfigReader.getpostjsonUrl());
        String postURL = String.format("%s", "https://" + ConfigReader.getbaseURL());

        RequestSpecification request = given();
        request.contentType("application/json").when().body(file);
        System.out.println("Base URL: "+postURL);
        System.out.println("Request Body: "+request.log().body());

        response = request.post(postURL);

        CommonValidation.verifyStatusCode(response,APIStatus.statusCodes.SUCCESS_CREATED);

        String responesId = ConfigReader.getuserId();
        CommonValidation.verifyPostValue(response,responesId);
        System.out.println("Status Code : "+response.statusCode());

        testLog(postURL,response);
        expAndActual(responesId, response.jsonPath().get("id").toString());
    }



    @Test (priority=3)
    void badRequestPost() {
        System.out.println("Test Case : Bad Request for Post Method");
        //POST Operation
        File file = new File(ConfigReader.getpostjsonUrl());
        String postURL = String.format("%s", "https://" + ConfigReader.getbaseURL()+"$$$");

        RequestSpecification request = given();
        request.contentType("application/json").when().body(file);
        System.out.println("Base URL: "+postURL);
        System.out.println("Request Body: "+request.log().body());

        response = request.post(postURL);
        int Status_code = response.getStatusCode();
        CommonValidation.verifyStatusCode(response,APIStatus.statusCodes.BAD_REQUEST_400);

        testLog(postURL,response);
        expAndActual(String.valueOf(Status_code), response.jsonPath().get("id").toString());
    }


}
