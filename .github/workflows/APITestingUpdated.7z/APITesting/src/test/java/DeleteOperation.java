import CommonValidation.CommonValidation;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import utility.ConfigReader;
import CommonValidation.APIStatus;
import utility.ExtentReportListner;

import static io.restassured.RestAssured.given;

public class DeleteOperation extends ExtentReportListner {
    public static Response response;
    @Test (priority=1)
    void deleteRequest(){
        System.out.println("Test Case : Delete Request");
        //Delete Operation

        String getHostGet = String.format("%s", "https://" + ConfigReader.getbaseURL());
        String UpdateURI = getHostGet + ConfigReader.getuserId();

        System.out.println("Delete Request URI: " + UpdateURI);
        response = given().delete(UpdateURI);
        System.out.println("Status Code : "+response.statusCode());
        System.out.println("Delete Response : "+response.asString());
        CommonValidation.verifyStatusCode(response, APIStatus.statusCodes.SUCCESS_DELETED);

        testLog(UpdateURI,response);
        expAndActual(String.valueOf(response.getStatusCode()),String.valueOf(APIStatus.statusCodes.SUCCESS_DELETED));

    }

    @Test (priority=2)
    void invalidDeleteRequest(){
        //invalid Delete Request and Successful delete request will give 204 no content response

        System.out.println("Test Case : Invalid Response Delete Request");
        //Delete Operation
        String getHostGet = String.format("%s", "https://" + ConfigReader.getbaseURL());
        String UpdateURI = getHostGet + "123#";


        System.out.println("Delete Request URI: " + UpdateURI);
        response = given().delete(UpdateURI);
        System.out.println("Delete Response : "+response.asString());
        System.out.println("Status Code : "+response.statusCode());

        CommonValidation.verifyStatusCode(response, APIStatus.statusCodes.SUCCESS_DELETED);
        testLog(UpdateURI,response);
        expAndActual(String.valueOf(response.getStatusCode()),String.valueOf(APIStatus.statusCodes.SUCCESS_DELETED));
    }
}
