import CommonValidation.CommonValidation;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.annotations.Test;
import utility.ConfigReader;
import CommonValidation.APIStatus;
import utility.ExtentReportListner;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import static io.restassured.RestAssured.given;

public class PutOperation extends ExtentReportListner {
    public static Response response;

    @Test (priority=1)
    void putRequestValid() {
        System.out.println("Test Case : Put Request Valid");
        //PUT Operation
        File file = new File(ConfigReader.getputJsonURL());
        String puttURL = String.format("%s", "https://" + ConfigReader.getbaseURL() + ConfigReader.getuserId());

        RequestSpecification request = given();
        request.contentType("application/json").when().body(file);
        System.out.println("Base URL: "+puttURL);
        System.out.println("Request Body: "+request.log().body());

        response = request.put(puttURL);

        CommonValidation.verifyStatusCode(response, APIStatus.statusCodes.SUCCESS);
        System.out.println("Response Body: "+response.asString());
        String responesJob = ConfigReader.getupdatedJob();
        CommonValidation.verifyPutJobValue(response,responesJob);
        System.out.println("Status Code : "+response.statusCode());

        testLog(puttURL,response);
        expAndActual(responesJob, response.jsonPath().get("job").toString());
    }
        @Test (priority=2)
        void invalidURLPut() {
            System.out.println("Test Case : Special Char in URL Id");
            //PUT Operation
            File file = new File(ConfigReader.getputJsonURL());
            String puttURL = String.format("%s", "https://" + ConfigReader.getbaseURL() + "***");

            RequestSpecification request = given();
            request.contentType("application/json").when().body(file);
            System.out.println("Base URL: "+puttURL);
            System.out.println("Request Body: "+request.log().body());
            response = request.put(puttURL);

            CommonValidation.verifyStatusCode(response, APIStatus.statusCodes.BAD_REQUEST_400);
            System.out.println("Response Body: "+response.asString());

            String responesName = ConfigReader.getupdatedName();
            CommonValidation.verifyNameValue(response,responesName);
            System.out.println("Status Code : "+response.statusCode());

            testLog(puttURL,response);
            expAndActual(responesName, response.jsonPath().get("name").toString());
        }


    @Test (priority=3)
    void invalidNamePutResponse() {
        System.out.println("Test Case : Invalid Name in Response Verification");
        //PUT Operation
        File file = new File(ConfigReader.getputJsonURL());
        String puttURL = String.format("%s", "https://" + ConfigReader.getbaseURL() + ConfigReader.getuserId());

        RequestSpecification request = given();
        request.contentType("application/json").when().body(file);
        System.out.println("Base URL: " + puttURL);
        System.out.println("Request Body: " + request.log().body());
        response = request.put(puttURL);

        CommonValidation.verifyStatusCode(response, APIStatus.statusCodes.SUCCESS);

        JSONParser parser = new JSONParser();
        try {
            Object obj = parser.parse(new FileReader(ConfigReader.getInvalidpostputJsonURL()));

            JSONObject jsonObject = (JSONObject) obj;
            String responseName = (String) jsonObject.get("name");

            CommonValidation.verifyNameValue(response, responseName);
            System.out.println("Status Code : " + response.statusCode());

            testLog(puttURL, response);
            expAndActual(responseName, response.jsonPath().get("name").toString());

        } catch (ParseException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
