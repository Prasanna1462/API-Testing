package utility;

import java.io.IOException;
import java.util.Properties;

public class ConfigReader {
    private static final String CONFIG_FILE = "config.properties";
    private static final Properties PROPERTIES = new Properties();
    static {
        try {
            PROPERTIES.load(ConfigReader.class.getClassLoader().getResourceAsStream(CONFIG_FILE));
        } catch (IOException e) {
            System.out.println("Config loading failed");
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }


    public static String getbaseURL(){
        return PROPERTIES.getProperty("baseURL");
    }
    public static String getpostjsonUrl(){
        return PROPERTIES.getProperty("postJsonURL");
    }
    public static String getputJsonURL(){
        return PROPERTIES.getProperty("putJsonURL");
    }
    public static String getInvalidpostputJsonURL(){
        return PROPERTIES.getProperty("invalidPostPutURL");
    }

    public static String getvalidName() {
        return PROPERTIES.getProperty("validName");
    }

    public static String getupdatedName(){
        return PROPERTIES.getProperty("updatedName");
    }
    public static String getupdatedJob(){
        return PROPERTIES.getProperty("updatedJob");
    }
    public static String getuserId(){
        return PROPERTIES.getProperty("UserId");

    }
}

