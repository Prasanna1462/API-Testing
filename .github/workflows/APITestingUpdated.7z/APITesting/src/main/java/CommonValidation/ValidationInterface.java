package CommonValidation;

public interface ValidationInterface {

    public int getHttpResponseCode();
    public Object getErrorCode();
    public String getErrorMessages();
    public String getMessage();
    public interface DetailErrorsInterface{
        public String getErrorDetailField();
        public String getErrorDetailMessage();
    }

}
