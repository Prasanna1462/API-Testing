package CommonValidation;

public class APIStatus {
    public enum statusCodes implements ValidationInterface{
        SUCCESS(200, null, null, null),
        SUCCESS_CREATED(201, null, null, null),
        SUCCESS_DELETED(204, null, null, null),
        BAD_REQUEST_400(400, null, null, null),
        NOT_FOUND_404(404,null,null,null),
        ERROR_500(500, null, null, null);

        private int httpResponseCode;
        private String errorCode;
        private String errorMessages;
        private String message;
        statusCodes(int httpResponseCode, String errorCode, String errorMessages, String message){
            this.httpResponseCode = httpResponseCode;
            this.errorCode = errorCode;
            this.errorMessages = errorMessages;
            this.message = message;
        }
        public int getHttpResponseCode() {
            return httpResponseCode;
        }

        public Object getErrorCode() {
            return errorCode;
        }

        public String getErrorMessages() {
            return errorMessages;
        }

        public String getMessage() {
            return message;
        }
    }
}
