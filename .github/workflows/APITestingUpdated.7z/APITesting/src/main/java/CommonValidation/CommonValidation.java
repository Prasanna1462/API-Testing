package CommonValidation;
import io.restassured.response.Response;
import org.testng.Assert;


public class CommonValidation {

        public static void verifyStatusCode(Response response, APIStatus.statusCodes Expectedcode) {
                String actualCode = "";
                if(response.getStatusCode() == 200){ actualCode="SUCCESS"; }
                else if(response.getStatusCode() == 201){ actualCode="SUCCESS_CREATED"; }
                else if(response.getStatusCode() == 204){ actualCode="SUCCESS_DELETED"; }
                else if(response.getStatusCode() == 400){ actualCode="BAD_REQUEST_400"; }
                else if(response.getStatusCode() == 404){ actualCode="NOT_FOUND_404"; }
                else if(response.getStatusCode() == 500){ actualCode="ERROR_500"; }


                Assert.assertEquals(actualCode, Expectedcode.toString());
        }


        public static void verifyGetidValue(Response response, String idValue) {
                Assert.assertEquals((response.jsonPath().get("data.id[0]").toString()),idValue);
        }

        public static void verifyPostValue(Response response, String responesId) {
                Assert.assertEquals((response.jsonPath().get("id").toString()),responesId);
        }

        public static void verifyNameValue(Response response, String responseName) {
                Assert.assertEquals((response.jsonPath().get("name").toString()),responseName);
        }

        public static void verifyPutJobValue(Response response, String responseName) {
                Assert.assertEquals((response.jsonPath().get("job").toString()),responseName);
        }


}
